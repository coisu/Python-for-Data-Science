def count_in_list(lst: list, item_to_count) -> int:
    """
    리스트에서 특정 아이템이 몇 번 나타나는지 개수를 셉니다.
    """
    return lst.count(item_to_count)