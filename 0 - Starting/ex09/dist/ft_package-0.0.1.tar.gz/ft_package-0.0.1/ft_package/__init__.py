# analysis.py 파일에서 count_in_list 함수를 가져와
# ft_package 패키지에서 바로 접근할 수 있도록 만듭니다.
from .analysis import count_in_list

# 패키지 버전이나 저자 같은 정보를 이곳에 정의하기도 합니다.
__version__ = "0.0.1"
__author__ = "eagle"
